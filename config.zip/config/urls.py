
from django.contrib import admin
from django.urls import path

from appointments import views


urlpatterns = [
    path("admin/", admin.site.urls),

    path("", views.home, name="home"),

    path(
        "patient/register/",
        views.register_patient,
        name="register_patient",
    ),
    path(
        "patient/login/",
        views.patient_login,
        name="patient_login",
    ),
    path(
        "patient/logout/",
        views.patient_logout,
        name="patient_logout",
    ),

    path(
        "book/",
        views.book_appointment,
        name="book_appointment",
    ),
    path(
        "appointments/",
        views.my_appointments,
        name="my_appointments",
    ),
    path(
        "cancel/<int:appointment_id>/",
        views.cancel_appointment,
        name="cancel_appointment",
    ),

    path(
        "doctor/login/",
        views.doctor_login,
        name="doctor_login",
    ),
    path(
        "doctor/dashboard/",
        views.doctor_dashboard,
        name="doctor_dashboard",
    ),
    path(
        "doctor/appointment/<int:appointment_id>/status/",
        views.update_appointment_status,
        name="update_appointment_status",
    ),
    path(
        "doctor/logout/",
        views.doctor_logout,
        name="doctor_logout",
    ),
]
