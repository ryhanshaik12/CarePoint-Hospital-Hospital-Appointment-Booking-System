
from datetime import date

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import AppointmentForm, PatientRegistrationForm
from .models import Appointment, Doctor


def is_doctor(user):
    return user.is_authenticated and hasattr(user, "doctor_profile")


def is_patient(user):
    return (
        user.is_authenticated
        and not user.is_staff
        and not is_doctor(user)
    )


def home(request):
    return render(
        request,
        "appointments/home.html",
        {"doctors": Doctor.objects.all().order_by("name")},
    )


def register_patient(request):
    if request.user.is_authenticated:
        return redirect("home")

    if request.method == "POST":
        form = PatientRegistrationForm(request.POST)

        if form.is_valid():
            user = form.save()

            login(
                request,
                user,
                backend="django.contrib.auth.backends.ModelBackend",
            )

            messages.success(
                request,
                "Your patient account has been created successfully.",
            )
            return redirect("home")
    else:
        form = PatientRegistrationForm()

    return render(
        request,
        "appointments/register.html",
        {"form": form},
    )


def patient_login(request):
    if request.user.is_authenticated:
        return redirect("home")

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "")

        user = authenticate(
            request,
            username=username,
            password=password,
        )

        if user is not None and is_patient(user):
            login(request, user)
            messages.success(request, "Welcome back!")
            return redirect("home")

        messages.error(
            request,
            "Invalid patient username or password.",
        )

    return render(request, "appointments/patient_login.html")


@require_POST
@login_required
def patient_logout(request):
    if is_doctor(request.user):
        return redirect("doctor_dashboard")

    logout(request)
    messages.success(request, "You have logged out.")
    return redirect("home")


@login_required
def book_appointment(request):
    if not is_patient(request.user):
        messages.error(
            request,
            "Please use a patient account to book an appointment.",
        )
        return redirect("home")

    if request.method == "POST":
        form = AppointmentForm(request.POST)

        if form.is_valid():
            selected_date = form.cleaned_data["appointment_date"]
            selected_time = form.cleaned_data["appointment_time"]
            selected_doctor = form.cleaned_data["doctor"]

            if selected_date < date.today():
                form.add_error(
                    "appointment_date",
                    "Please select today or a future date.",
                )
            else:
                # Check whether this doctor's selected slot is occupied.
                slot_taken = Appointment.objects.filter(
                    doctor=selected_doctor,
                    appointment_date=selected_date,
                    appointment_time=selected_time,
                ).exclude(
                    status="Cancelled"
                ).exists()

                if slot_taken:
                    form.add_error(
                        None,
                        "This doctor already has an appointment "
                        "at that date and time. Please choose "
                        "another time.",
                    )
                else:
                    appointment = form.save(commit=False)
                    appointment.patient = request.user
                    appointment.patient_name = (
                        request.user.get_full_name()
                        or request.user.username
                    )
                    appointment.patient_email = request.user.email
                    appointment.save()

                    messages.success(
                        request,
                        "Your appointment has been booked successfully.",
                    )
                    return redirect("my_appointments")
    else:
        form = AppointmentForm()

    return render(
        request,
        "appointments/book.html",
        {"form": form},
    )


@login_required
def my_appointments(request):
    if not is_patient(request.user):
        messages.error(
            request,
            "This page is for patient accounts.",
        )
        return redirect("home")

    appointments = (
        Appointment.objects
        .filter(patient=request.user)
        .select_related("doctor")
        .order_by("appointment_date", "appointment_time")
    )

    return render(
        request,
        "appointments/list.html",
        {"appointments": appointments},
    )


@require_POST
@login_required
def cancel_appointment(request, appointment_id):
    if not is_patient(request.user):
        messages.error(
            request,
            "Only patients can cancel their own appointments.",
        )
        return redirect("home")

    appointment = get_object_or_404(
        Appointment,
        id=appointment_id,
        patient=request.user,
    )

    appointment.delete()

    messages.success(
        request,
        "Your appointment has been cancelled.",
    )
    return redirect("my_appointments")


def doctor_login(request):
    if request.user.is_authenticated:
        if is_doctor(request.user):
            return redirect("doctor_dashboard")
        return redirect("home")

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "")

        user = authenticate(
            request,
            username=username,
            password=password,
        )

        if user is not None and is_doctor(user):
            login(request, user)
            return redirect("doctor_dashboard")

        messages.error(
            request,
            "Invalid credentials or no doctor profile is linked "
            "to this account.",
        )

    return render(request, "appointments/doctor_login.html")


@login_required
def doctor_dashboard(request):
    if not is_doctor(request.user):
        messages.error(
            request,
            "Please log in using your doctor account.",
        )
        return redirect("doctor_login")

    doctor = request.user.doctor_profile

    appointments = (
        Appointment.objects
        .filter(doctor=doctor)
        .select_related("doctor", "patient")
        .order_by("appointment_date", "appointment_time")
    )

    return render(
        request,
        "appointments/doctor_dashboard.html",
        {
            "doctor": doctor,
            "appointments": appointments,
        },
    )


@require_POST
@login_required
def update_appointment_status(request, appointment_id):
    if not is_doctor(request.user):
        messages.error(
            request,
            "Only doctors can update appointment status.",
        )
        return redirect("doctor_login")

    doctor = request.user.doctor_profile

    appointment = get_object_or_404(
        Appointment,
        id=appointment_id,
        doctor=doctor,
    )

    new_status = request.POST.get("status", "").strip()

    allowed_statuses = {
        "Approved",
        "Completed",
        "Cancelled",
    }

    if new_status not in allowed_statuses:
        messages.error(request, "Invalid appointment status.")
        return redirect("doctor_dashboard")

    appointment.status = new_status
    appointment.save(update_fields=["status"])

    messages.success(
        request,
        f"Appointment status updated to {new_status}.",
    )

    return redirect("doctor_dashboard")


@require_POST
@login_required
def doctor_logout(request):
    if not is_doctor(request.user):
        return redirect("home")

    logout(request)
    messages.success(request, "You have logged out.")
    return redirect("home")
