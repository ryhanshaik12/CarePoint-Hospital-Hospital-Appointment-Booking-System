
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password

from .models import Appointment


class PatientRegistrationForm(forms.ModelForm):
    password = forms.CharField(
        label="Password",
        widget=forms.PasswordInput,
        validators=[validate_password],
    )

    confirm_password = forms.CharField(
        label="Confirm password",
        widget=forms.PasswordInput,
    )

    class Meta:
        model = User
        fields = [
            "username",
            "first_name",
            "last_name",
            "email",
        ]

        widgets = {
            "username": forms.TextInput(attrs={
                "autocomplete": "username",
            }),
            "first_name": forms.TextInput(attrs={
                "autocomplete": "given-name",
            }),
            "last_name": forms.TextInput(attrs={
                "autocomplete": "family-name",
            }),
            "email": forms.EmailInput(attrs={
                "autocomplete": "email",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["email"].required = True
        self.fields["first_name"].required = True
        self.fields["last_name"].required = True

    def clean_username(self):
        username = self.cleaned_data["username"].strip()

        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError(
                "This username is already taken."
            )

        return username

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()

        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError(
                "An account with this email already exists."
            )

        return email

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if (
            password
            and confirm_password
            and password != confirm_password
        ):
            self.add_error(
                "confirm_password",
                "The passwords do not match.",
            )

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"].strip().lower()
        user.set_password(self.cleaned_data["password"])

        if commit:
            user.save()

        return user


class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = [
            "doctor",
            "appointment_date",
            "appointment_time",
            "reason",
        ]

        labels = {
            "doctor": "Choose a doctor",
            "appointment_date": "Appointment date",
            "appointment_time": "Appointment time",
            "reason": "Reason for your visit",
        }

        widgets = {
            "appointment_date": forms.DateInput(attrs={
                "type": "date",
            }),
            "appointment_time": forms.TimeInput(attrs={
                "type": "time",
            }),
            "reason": forms.Textarea(attrs={
                "rows": 4,
                "placeholder": "Briefly describe your reason for visiting",
            }),
        }
