
from django.contrib import admin

from .models import Appointment, Doctor


@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ("name", "specialization", "user")
    search_fields = ("name", "specialization", "user__username")


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = (
        "patient_name",
        "doctor",
        "appointment_date",
        "appointment_time",
    )
    list_filter = ("appointment_date", "doctor")
    search_fields = (
        "patient_name",
        "patient_email",
        "doctor__name",
    )
    date_hierarchy = "appointment_date"
